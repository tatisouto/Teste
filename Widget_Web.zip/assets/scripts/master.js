/**
const { ipcRenderer } = require('electron');

const CHANNEL_NAME = 'main';
const MESSAGE = 'ping';
  

 SYNCHRONOUS
 
console.log(ipcRenderer.sendSync(CHANNEL_NAME, MESSAGE)); // send request and show response 

*/  
$(document).ready(function() {
    const database = firebase.database();


    /*
        UPDATE AD
    */


    database.ref('/images').on('value', function(data) {
        if (data.exists()) {
            $("img.advertises ").attr("src", data.node_.value_);
        }
    });

    /*
        PROFILE INFO
    */

    var id;
    var user;
    var token;
    var ric_active;
    var isGreen;
    var startTime_active = new Date();
    var delay_active = "HOUR";
    var mac = "DEVICE_20006331_widget";
    var image = 1;
    var quotedelay = 5000;
    var force_realtime = true;


    /*
        GENERIC API CALL
    */

    const sendRequest = (dev, urldata, method, body, caller) => {
        var domain;
        var auth_token;

        console.log(dev)

        if (dev === "int") {
            domain = "https://api.bescom.bes.gbes/api/v1/Quotes/" + urldata;
            auth_token = "OAuth access_token=a90ac3d977704c36baf97740b8ccd723,oauth_consumer_key=829fe1b0ba0c209241280fda75f6ab79e4ba2015bfc1e7859b40781f7db275ef,oauth_timestamp=2527679516,oauth_version=1.0,oauth_signature=4G%2BFhdAdarxM7cJNP%2FsqhHZXsVJdnwk2zP0QtbZXbr4%3D";
        } else if (dev === "qbc") {

            domain = "https://api.bstqbc.pt/api/v1/Quotes/" + urldata;
            auth_token = 'OAuth access_token=581a9d1dc0c8407f8e2883ffba2816fd,oauth_consumer_key=b0b2c4dde60ae596b5f374479ae532384074a827b56ee45114ee7e74d271f6b3,oauth_timestamp=2527679516,oauth_version=1.0,oauth_signature=L02%2B79DseewaEqZ4apmeOqb5z2%2F2GljYxCgz0FxKUTQ%3D';

        } else {

            domain = "https://api.bancobest.pt/api/v1/Quotes/" + urldata;
            auth_token = 'OAuth access_token=045f305cfc3743a094268c9ba686ea35,oauth_consumer_key=cec2d7c7fdb1a1334f41793ece929234059a725b89be9b1ec772fdfa918d72ba,oauth_timestamp=2527679516,oauth_version=1.0,oauth_signature=mxRqrCuKfgz7cAKrCfyYo10y%2B42SEVwp%2FP4iG0v%2FFGM%3D';

        }

        // START PERFORMANCE CHECK
        var t0 = performance.now();

        $.ajax({
            url: domain,
            type: method,
            data: JSON.stringify(body),
            headers: {
                "Authorization": auth_token,
            },
            contentType: 'application/json; charset=utf-8',
            dataType: 'json',
            success: function(data) {

                // STOP  PERFORMANCE CHECK
                var t1 = performance.now();
                console.log(caller + " | " + parseFloat(t1 - t0).toFixed(2) + " ms");


                switch (caller) {
                    case 'LOGIN':
                        console.log(data["returnMsg"]);
                        if (data["returnMsg"] === "Sucesso") {
                            id = data["outputData"]["object_id"];
                            slide(1);
                            console.log(id + " | ID UPDATED");
                        } else {
                            $("#username").addClass("error");
                            $("#password").addClass("error");
                        }
                        break;
                    case 'OTP':
                        if (data["returnMsg"] === "Sucesso") {
                            token = data["outputData"]["apiToken"];
                            console.log(token + " | TOKEN UPDATED");
                            wallet(token);
                        } else {
                            $("#password").addClass("error");
                        }
                        break;
                    case 'WALLET':
                        if (data["returnMsg"] === "Sucesso") {
                            var data_filtered = data["outputData"]["listOfSecurities"]["streamer"];
                            console.table(data_filtered)
                            generateContent(data_filtered)
                        } else {
                            $("#password").addClass("error");
                        }
                        break;
                    case 'UPDATECHART':
                        var data_filtered = data["GetIntradayTimeSeries_Response_5"]["Row"];
                        console.table(data_filtered)
                        getGraph(ric_active, isGreen, data_filtered)

                        break;
                    case 'QUOTES':
                        var data_filtered = data;
                        //console.table(data)
                        updateQuotes(data_filtered)

                        break;
                    default:
                        break;
                }


            }
        });
    }

    /* 
        CALLS CONSTRUCTORS
    */

    const checklogin = async (username, password) => {

        user = username.toUpperCase();

        var body = {
            "user": username.toUpperCase(),
            "pass": password,
            "encrypt": "N",
            "device_id": mac,
            "app_version": "1.0"
        }
        var urldata = 'Widget_checkLogin'
        sendRequest("prd", urldata, 'post', body, 'LOGIN')
    }

    const checkotp = async (otp) => {
        var body = {
            "object_id": id,
            "auth_type": "3",
            "auth_value": otp,
            "device_id": mac
        }
        var urldata = 'Widget_checkLoginSecure'
        sendRequest("prd", urldata, 'post', body, 'OTP')
    }






    const wallet = async (token) => {
        var body = {
            "user": user,
            "token": token,
            "device_id": mac
        }
        console.log(body);
        var urldata = 'Securities_getStreamerInfo'
        sendRequest("prd", urldata, 'post', body, 'WALLET')
    }


    const updateChart = async (ric, less, interval) => {
        console.log(datetoString(todayless(less)))
        console.log(moment().format('YYYY-MM-DDTHH:mm:ss'));
        var body = {
            "user": user,
            "token": token,
            "device_id": mac,
            "GetIntradayTimeSeries_Request_5": {
                "Symbol": ric,
                "StartTime": datetoString(todayless(less)),
                "EndTime": moment().format('YYYY-MM-DDTHH:mm'),
                "TrimResponse": false,
                "Interval": interval
            }
        }
        console.log(body);

        var urldata = 'SeriesIntraday';
        sendRequest("prd", urldata, 'post', body, 'UPDATECHART')
    }


    const getQuotes = async (ricData) => {


        var body = {
            "user": user,
            "token": token,
            "device_id": mac,
            "RetrieveItem_Request_3": {
                "ItemRequest": [{
                    "Fields": "",
                    "RequestKey": ricData,
                    "Scope": "All"
                }],
                "TrimResponse": false,
                "IncludeChildItemQoS": false
            }
        }
        console.log(body);
        var urldata = 'Quotes'
        sendRequest("prd", urldata, 'post', body, 'QUOTES')
    }


    
    /* 
        ELEMENT CONSTRUCTORS
    */


    const updateQuotes = async (data) => {


        Object.keys(data).forEach(function(item) {
            var element = data[item];
            console.log(element)
            //console.table(data[item])
            var ric = element["Ric"].replace(".", "");
            var price = element["Price"];
            var openprice = element["Open_price"];
            var prev = parseFloat(Number($("li[ricp=" + ric + "] p span").text())).toFixed(2);
            var after = parseFloat(Number(price)).toFixed(2);
            var decreaseValue = prev - after;
            var rent = parseFloat((decreaseValue / prev) * 100).toFixed(2);


            // RICP = RIC SEM O "." 
            $("li[ricp=" + ric + "]").attr("op", openprice);


            if (prev > after) {
                $('li[ricp="' + ric + '"] p.varrend').removeClass("green").addClass("red")
                $('li[ricp="' + ric + '"] p.varrend').text(rent + " %")
            } else if (after > prev) {
                $('li[ricp="' + ric + '"] p.varrend').removeClass("red").addClass("green")
                $('li[ricp="' + ric + '"] p.varrend').text(rent + " %")
            } else {
                $('li[ricp="' + ric + '"] p.varrend').removeClass("red").removeClass("green")
                $('li[ricp="' + ric + '"] p.varrend').text("0 %")
            }

            $("li[ricp=" + ric + "] p span").text(parseFloat(price).toFixed(2));


            /* ADD LIST TO SEARCH */

            var entry = '<li search_ric="'+ric+'" name="' + element["Name"] + '">' + element["Ric"] + '</li>';

            if ($('.searchable li[search_ric="' + ric + '"]').length < 1) {
                $(".searchable").append(entry)
            }



            /* ADD TABLE */

            var table = 
            `
            <tr>
               <th colspan="2">COMPRADORES</th>
               <th colspan="2">VENDEDORES</th>
            </tr>
            <tr>
               <td>Qtd</td>
               <td>Preço</td>
               <td class="t_right">Preço</td>
               <td class="t_right">Qtd</td>
            </tr>
            <tr>
               <td>${element["bid_size_1"]}</td>
               <td>${element["bid_price_1"]}</td>
               <td class="t_right">${element["ask_price_1"]}</td>
               <td class="t_right">${element["ask_size_1"]}</td>
            </tr>
            <tr>
               <td>${element["bid_size_2"]}</td>
               <td>${element["bid_price_2"]}</td>
               <td class="t_right">${element["ask_price_2"]}</td>
               <td class="t_right">${element["ask_size_2"]}</td>
            </tr>
            <tr>
               <td>${element["bid_size_3"]}</td>
               <td>${element["bid_price_3"]}</td>
               <td class="t_right">${element["ask_price_3"]}</td>
               <td class="t_right">${element["ask_size_3"]}</td>
            </tr>
            <tr>
               <td>${element["bid_size_4"]}</td>
               <td>${element["bid_price_4"]}</td>
               <td class="t_right">${element["ask_price_4"]}</td>
               <td class="t_right">${element["ask_size_4"]}</td>
            </tr>
            <tr>
               <td>${element["bid_size_5"]}</td>
               <td>${element["bid_price_5"]}</td>
               <td class="t_right">${element["ask_price_5"]}</td>
               <td class="t_right">${element["ask_size_5"]}</td>
            </tr>
            `;
            
            $("li[ricp=" + ric + "] .table").html(table);
        });


    }


    /*
        LOGIN / OTP / REGISTER PANEL CONTROL
    */

    var panelOne = $('.form-panel.two').height(),
        panelTwo = $('.form-panel.two')[0].scrollHeight;

    $('.form-panel.two').not('.form-panel.two.active').on('click', function(e) {
        e.preventDefault();

        $('.form-toggle').addClass('visible');
        $('.form-panel.one').addClass('hidden');
        $('.form-panel.two').addClass('active');
        $('.form').animate({
            'height': panelTwo
        }, 200);
    });

    $('.form-toggle').on('click', function(e) {
        e.preventDefault();
        $(this).removeClass('visible');
        $('.form-panel.one').removeClass('hidden');
        $('.form-panel.two').removeClass('active');
        $('.form').animate({
            'height': panelOne
        }, 200);
    });

    $('.form-group').on('click', '#submit.login', function(e) {
        e.preventDefault();

        var username = $('#username').val().toUpperCase();
        var password = $('#password').val();
        checklogin(username, password);
    });

    $('.form-group').on('click', '#submit.verify', function(e) {
        e.preventDefault();
        var otp = $('#username').val();
        checkotp(otp);
    });


    function slide(num) {
        if (num === 1) {
            $('.form-header h1').text('Account Verification');
            $('body > div > div.form-panel.one > div.form-content > form > div:nth-child(1) > label').text('OTP Code')
            $('body > div > div.form-panel.one > div.form-content > form > div:nth-child(2)').hide();
            $('body > div > div.form-panel.one > div.form-content > form > div:nth-child(3)').hide();
            $('#submit').removeClass('login').addClass('verify');
            $('#submit').text('Verify');
            $('#username').val('');
        } else {
            $('.form-header h1').text('Account Login');
            $('body > div > div.form-panel.one > div.form-content > form > div:nth-child(1) > label').text('USERNAME')
            $('body > div > div.form-panel.one > div.form-content > form > div:nth-child(2)').show();
            $('body > div > div.form-panel.one > div.form-content > form > div:nth-child(3)').show();
            $('#submit').removeClass('verify').addClass('login');
            $('#submit').text('LOG IN');
            $('#username').val('');
        }
    }



    // LIST OF ARRAYS TO CALL UPDATE QUOTES
    var arrayRic = [];

    function generateContent(data) {



        Object.keys(data).forEach(function(item) {
            var element = data[item];
            //console.table(data[item])
            var elements = '';
            var haselements = 'solo';
            var ric = element["ric"];
            var varrend = element["variacao"];
            var mercado = element["mercado"].split("#")[0];
            var realtime =  element["mercado"].split("#")[1];

            if (realtime == 0 || force_realtime === true) {
                arrayRic.push({
                    "Name": "0#" + ric,
                    "NameType": "RIC"
                })
            } else {
                arrayRic.push({
                    "Name": ric,
                    "NameType": "RIC"
                })
            }

       


            if (element["quantidade"] != null && element["cotacao"] != null) {
                var ganhos = (Number(element["quantidade"]) * Number(element["compra"])) - (Number(element["quantidade"]) * Number(element["cotacao"]))
                ganhos = ' (' + parseFloat(ganhos).toFixed(2) + ')';
                varrend = parseFloat(element["rentabilizacao"]).toFixed(2)
                elements = elements + '<span class="quant"> <p>' + Number(element["quantidade"]) + '</p></span>' + '<p class="wallet">' + Number(element["quantidade"]) * Number(element["cotacao"]) + ganhos + '</p>' + '<p class="wallet">' + Number(element["quantidade"]) * Number(element["cotacao"]) + ganhos + '</p>' + '<p class="wallet">' + Number(element["quantidade"]) * Number(element["cotacao"]) + ganhos + '</p>';
                haselements = '';
            }

            var operator = 'green';
            if (varrend.toString().includes("-")) {
                operator = 'red'
            }

            if ($('li[ricp=' + ric.toString().replace(".", "") + ']').length > 0) {

            } else {
                $('.sidepanel').append('<li ric="' + ric + '" ricp="' + ric.toString().replace(".", "") + '"> <div> <div class="expand"></div> <img class="limit" src="../assets/images/logos/' + image + '.jpg" alt=""> ' + '<p class="name ' + haselements + '" >' + element["sigla"] + '</p>' + elements + '<p class="cot"><span>' + parseFloat(Number(element["cotacao"])).toFixed(2) + '</span> ' + element["moeda"] + '</p>' + '<p class="varrend ' + operator + '">' + parseFloat(Number(varrend)).toFixed(2) + ' %</p> <div> <div class="container"> <div class="visual" > <div class="chart" id="' + ric.toString().replace(".", "") + '"> <div class="reload"> </div> </div> <div class="list"> <div class="active">1D</div> <div>1S</div> <div class="">1M</div> <div>3M</div> <div>1A</div> </div> <div class="buysell"> <div class="slide"> <div> <p>48.27 EUR</p> <p class="small">Valor fecho anterior</p> </div> <div><p>0 EUR</p> <p class="small">Valor abertura</p> </div> </div> </div> <table class="table"></table> <img class="advertises" src="" alt=""> </div> </div>' + ' </li>');
                image = image + 1;
                if (image === 10) {
                    image = 1;
                }
            }

        });

        getQuotes(arrayRic);
        setInterval(() => {
            getQuotes(arrayRic);
        }, quotedelay);
        firstChart();

        $('.form').hide();
        $('.wrapper').addClass('show');
    }


    /*
        TIME FUNCTIONS
    */

    function datetoString(num) {
        return num.toISOString().slice(0, 10) + 'T00:00:00';
    }

    function stringtoDate(string) {
        return Date.parse(string);
    }

    function todayless(less) {
        var now = new Date();
        now.setDate(now.getDate() - less);
        return now;
    }



    /* 
        EXPAND AND COLLAPSE <LI> ON SIDEPANEL
    */

    $(".sidepanel").on("click", "li:not(.active) .expand", function() {
        $(".sidepanel li").removeClass("active");
        $(this).parent().parent().addClass("active");
        var ric = $(this).parent().parent().attr("ric");
        var op = $(this).parent().parent().attr("op");
        var green = $(this).parent().parent().find('p').hasClass("green");
        console.log(ric + " | active ric");
        ric_active = ric;
        isGreen = green;
        updateChart(ric, 1, "HOUR");
        $("body > div.wrapper.show > div.visual > div.buysell > div > div:nth-child(2) > p:nth-child(1)").text(op + " " + $(this).parent().parent().find("p.cot").text().split(" ")[1])
    });


    $(".sidepanel").on("click", "li.active .expand", function() {
        if ($(window).width() < 600) {
            $(".sidepanel li").removeClass("active");
        }
    });

    /*
        FIRST CHART CALL WITHOUT USER INTERACTION
    */

    function firstChart() {
        $(".sidepanel li").first().addClass("active");
        var ric = $(".sidepanel li").first().attr("ric")
        var green = $(".sidepanel li").first().find('p').hasClass("green");

        ric_active = ric;
        isGreen = green;

        updateChart(ric, 1, "HOUR");
    }

    /*
        CHART TIMERANGE CHANGE AND OPTIONS
    */

    $(".wrapper").on("click", ".visual .list div", function() {
        var delay = $(this).text();

        if (delay === "1D") {
            delay_active = 'HOUR';
            updateChart(ric_active, 0, delay_active);
        } else if (delay === "1S") {
            delay_active = 'HOUR';
            updateChart(ric_active, 7, delay_active);
        } else if (delay === "1M") {
            delay_active = 'HOUR';
            updateChart(ric_active, 30, delay_active);
        } else if (delay === "3M") {
            delay_active = 'HOUR';
            updateChart(ric_active, 90, delay_active);
        } else if (delay === "1A") {
            delay_active = 'HOUR';
            updateChart(ric_active, 395, delay_active);
        }

        $(".visual .list div").removeClass("active");
        $(this).toggleClass("active")
    });


    /*
        PREPARE DATA TO GENERATE CHARTS
    */
    function getGraph(ric, green, data) {
        var array = []
        var series = []
        var series_tool = []
        var i = 0;

        Object.keys(data).forEach(function(item) {
            var element = data[i]["CLOSE"];
            var time = data[i]["TIMESTAMP"].split("T")[0];
            var tooltip = data[i]["TIMESTAMP"].split("T")[1].split("+")[0];
            series.push(time);
            series_tool.push(tooltip)
            array.push(element);
            i++
        });

        console.table(series)

        $("body > div.wrapper.show > div.visual > div.buysell > div > div:nth-child(1) > p:nth-child(1)").text(data[data.length - 1]["CLOSE"] + ' EUR');

        if (green === true) {
            generateGraph(ric, series, series_tool, array, ['#51E2A6'])

        } else {
            generateGraph(ric, series, series_tool, array, ['#FF6060'])
        }

    }



    /*
        CHART OPTIONS CONFIG
    */
    function generateGraph(ric, series, series_tool, data, color) {
        $("#" + ric.replace(".", "")).html("");

        var options = {
            series: [{
                name: ric,
                data: data
            }],
            chart: {
                width: '100%',
                height: 350,
                type: 'area'
            },
            dataLabels: {
                enabled: false
            },
            colors: color,
            fill: {
                colors: color
            },
            stroke: {
                curve: 'smooth'
            },
            yaxis: {
                show: false
            },
            grid: {
                show: false
            },
            xaxis: {
                show: false,
                categories: series_tool,
                labels: {
                    show: false
                }
            },
            tooltip: {
                enabled: true
            },
        };

        var chart = new ApexCharts(document.querySelector("#" + ric.replace(".", "")), options);
        chart.render();

    }

    /*
        EXTRA JQUERY FUNTIONALITY
    */

    String.prototype.replaceAt = function(index, replacement) {
        return this.substr(0, index) + replacement + this.substr(index + replacement.length);
    }



    /*
        SEARCH MODULE
    */
    var searched_tag; 
    $(".search input").on("change keyup", function() {
        searched_tag = $(this).val().toUpperCase();
        console.log(searched_tag);

       

        $('.searchable li').each(function() {
            var name = $(this).attr("name");
            var ric = $(this).attr("search_ric");

            if (name.includes(searched_tag) || ric.includes(searched_tag.replace(".",""))) {
                $(this).addClass("focus");

                console.log(searched_tag) 

            } else{
                $('.searchable li').removeClass("focus");
            }
        });

        if ($('.searchable li.focus').length > 0 && searched_tag != "") {
            $('.searchable').show();
        } else {
            $('.searchable').hide();
        }
     });



    /*
        MESSAGES 
    */

    $(".messages").on("click", function(event) {
        event.preventDefault();
        event.stopPropagation();
        $(this).addClass("open")
    });

    $(".messages").on("click", '.top' , function(event) {
        event.preventDefault();
        event.stopPropagation();
        $(".messages").removeClass("open")
    });

    refresh_messages()

    function refresh_messages() {
        $(".bubble").remove()
        firebase.database().ref('message/20006331/user_text').once('value', (snap) => {
            var data = snap.val();
            var i = 0;
            var object_pt = '';

            $.each(data, function(index, value) {
                var messages = value[1];
                var meclass = value[0];
                if (meclass === "me") {
                    meclass = "you";
                } else {
                    meclass = "me"
                }
                object_pt = object_pt + '<div class="bubble ' + meclass + '">' + messages + '</div>';
            });

            object_pt = object_pt + '</div>';

            $(".chat").append(object_pt);



        });
    }

    function sendmsg(user, message, time) {

        message = ["you", message];

        firebase.database().ref('message/' + user + '/user_text').once('value', (snap) => {
            var data = snap.val();
            try {
                data.push(message);

            } catch (error) {
                data = [""].push(message);
            }

            firebase.database().ref('message/' + user).set({
                username: user,
                user_text: data,
                user_time: time
            });

            refresh_messages()
        });




    }



    $('.send').on('click', function() {
        var data = $("div.write > input[type=text]").val();

        var target = $("div.top span.name").text();

        var currentdate = new Date();
        var datetime = currentdate.getDate() + "/" +
            (currentdate.getMonth() + 1) + "/" +
            currentdate.getFullYear() + " @ " +
            currentdate.getHours() + ":" +
            currentdate.getMinutes() + ":" +
            currentdate.getSeconds();

        sendmsg("20006331", data, datetime)
    });



});